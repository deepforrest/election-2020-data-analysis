electoral_votes_array = []

# Electoral College:
electoral_votes_AL = 9
electoral_votes_AK = 3
electoral_votes_AZ = 11
electoral_votes_AR = 6
electoral_votes_CA = 55
electoral_votes_CO = 9
electoral_votes_CT = 7
electoral_votes_DC = 3
electoral_votes_DE = 3
electoral_votes_FL = 29
electoral_votes_GA = 16
electoral_votes_HI = 4
electoral_votes_ID = 4
electoral_votes_IL = 20
electoral_votes_IN = 11
electoral_votes_IA = 6
electoral_votes_KS = 6
electoral_votes_KY = 8
electoral_votes_LA = 8
electoral_votes_ME = 4
electoral_votes_MD = 10
electoral_votes_MA = 11
electoral_votes_MI = 16
electoral_votes_MN = 10
electoral_votes_MS = 6
electoral_votes_MO = 10
electoral_votes_MT = 3
electoral_votes_NE = 5
electoral_votes_NV = 6
electoral_votes_NH = 4
electoral_votes_NJ = 14
electoral_votes_NM = 5
electoral_votes_NY = 29
electoral_votes_NC = 15
electoral_votes_ND = 3
electoral_votes_OH = 18
electoral_votes_OK = 7
electoral_votes_OR = 7
electoral_votes_PA = 20
electoral_votes_RI = 4
electoral_votes_SC = 9
electoral_votes_SD = 3
electoral_votes_TN = 11
electoral_votes_TX = 38
electoral_votes_UT = 6
electoral_votes_VT = 3
electoral_votes_VA = 13
electoral_votes_WA = 12
electoral_votes_WV = 5
electoral_votes_WI = 10
electoral_votes_WY = 3

# Add each state's electoral college array:
electoral_votes_array.insert(0, electoral_votes_AL)
electoral_votes_array.insert(1, electoral_votes_AK)
electoral_votes_array.insert(2, electoral_votes_AZ)
electoral_votes_array.insert(3, electoral_votes_AR)
electoral_votes_array.insert(4, electoral_votes_CA)
electoral_votes_array.insert(5, electoral_votes_CO)
electoral_votes_array.insert(6, electoral_votes_CT)
electoral_votes_array.insert(7, electoral_votes_DC)
electoral_votes_array.insert(8, electoral_votes_DE)
electoral_votes_array.insert(9, electoral_votes_FL)
electoral_votes_array.insert(10, electoral_votes_GA)
electoral_votes_array.insert(11, electoral_votes_HI)
electoral_votes_array.insert(12, electoral_votes_ID)
electoral_votes_array.insert(13, electoral_votes_IL)
electoral_votes_array.insert(14, electoral_votes_IN)
electoral_votes_array.insert(15, electoral_votes_IA)
electoral_votes_array.insert(16, electoral_votes_KS)
electoral_votes_array.insert(17, electoral_votes_KY)
electoral_votes_array.insert(18, electoral_votes_LA)
electoral_votes_array.insert(19, electoral_votes_ME)
electoral_votes_array.insert(20, electoral_votes_MD)
electoral_votes_array.insert(21, electoral_votes_MA)
electoral_votes_array.insert(22, electoral_votes_MI)
electoral_votes_array.insert(23, electoral_votes_MN)
electoral_votes_array.insert(24, electoral_votes_MS)
electoral_votes_array.insert(25, electoral_votes_MO)
electoral_votes_array.insert(26, electoral_votes_MT)
electoral_votes_array.insert(27, electoral_votes_NE)
electoral_votes_array.insert(28, electoral_votes_NV)
electoral_votes_array.insert(29, electoral_votes_NH)
electoral_votes_array.insert(30, electoral_votes_NJ)
electoral_votes_array.insert(31, electoral_votes_NM)
electoral_votes_array.insert(32, electoral_votes_NY)
electoral_votes_array.insert(33, electoral_votes_NC)
electoral_votes_array.insert(34, electoral_votes_ND)
electoral_votes_array.insert(35, electoral_votes_OH)
electoral_votes_array.insert(36, electoral_votes_OK)
electoral_votes_array.insert(37, electoral_votes_OR)
electoral_votes_array.insert(38, electoral_votes_PA)
electoral_votes_array.insert(39, electoral_votes_RI)
electoral_votes_array.insert(40, electoral_votes_SC)
electoral_votes_array.insert(41, electoral_votes_SD)
electoral_votes_array.insert(42, electoral_votes_TN)
electoral_votes_array.insert(43, electoral_votes_TX)
electoral_votes_array.insert(44, electoral_votes_UT)
electoral_votes_array.insert(45, electoral_votes_VT)
electoral_votes_array.insert(46, electoral_votes_VA)
electoral_votes_array.insert(47, electoral_votes_WA)
electoral_votes_array.insert(48, electoral_votes_WV)
electoral_votes_array.insert(49, electoral_votes_WI)
electoral_votes_array.insert(50, electoral_votes_WY)

# For loop to add up the available electoral votes in each state:

from StateNames import states_array

total_electoral_votes = 0

for state in range(len(states_array)):
    total_electoral_votes += electoral_votes_array[state]