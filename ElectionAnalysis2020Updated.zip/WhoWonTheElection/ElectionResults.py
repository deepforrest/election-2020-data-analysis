# PROGRAM SUMMARY
# This program is a basic script that takes the numbers collected from the Associate Press
# Poll results and calculates who wins each state.  The only assumption in this model is that
# Maine and Nebraska will be considered all or nothing states, since right now they both have
# all but one electoral vote going to their respective winners, effectively cancelling each other
# out in reality.  The program uses for loops to determine the electoral winner of each state and
# then determines the winner of the election.

# Note: Popular vote numbers updated Monday, November 9th, 2020 at 1700 PDT.

# Data points are seperated into separate scripts:
from BidenVotes import biden_votes_array
from ElectoralVotes import electoral_votes_array
from StateNames import states_array
from TrumpVotes import trump_votes_array
from IndependentVotes import independent_votes_array

# Initialization of vote counts and counters:
biden_popular_votes = 0
trump_popular_votes = 0
independent_popular_votes = 0
total_popular_votes = 0

biden_electoral_votes = 0
trump_electoral_votes = 0
independent_electoral_votes = 0
cumulative_electoral_votes = 0

total_votes_array = []

contest_number = 1
total_contests = 51

from ElectoralVotes import total_electoral_votes

#*****************************************A*N*A*L*Y*S*I*S*****************************************

electoral_vote_threshold = total_electoral_votes // 2 + 1

print("There are {0} electoral votes up for grabs!".format(total_electoral_votes))
print("Each candidate must secure {0} electoral votes to win the presidental election.".format(electoral_vote_threshold))
print("In the event of a tie on the electoral vote, it will be up to Congress to decide.  Good luck!\n")

# This section of code ensures that I've entered different numbers for each candidate in each state:
for state in range(len(biden_votes_array)):
    if biden_votes_array[state] == trump_votes_array[state]:
        print("{0} have the same numbers and need their votes checked again!".format(states_array[state]))

for state in range(len(biden_votes_array)):
    total_votes_array.insert(state, biden_votes_array[state] + trump_votes_array[state] + independent_votes_array[state])

#for state in range(len(total_votes_array)):
#    print("Total for {0}: {1:,}".format(states_array[state], total_votes_array[state]))

# This section is important to determine who won each state and tally up their electoral vote counts:
for state in range(len(electoral_votes_array)):
    biden_popular_votes += biden_votes_array[state]
    trump_popular_votes += trump_votes_array[state]
    independent_popular_votes += independent_votes_array[state]
    cumulative_electoral_votes += electoral_votes_array[state]

    biden_popular_percentage = biden_votes_array[state] / total_votes_array[state]
    trump_popular_percentage = trump_votes_array[state] / total_votes_array[state]
    independent_popular_percentage = independent_votes_array[state] / total_votes_array[state]

    print("-----------------------------------------------------------------------")
    print("Contest #{0} - Popular Vote Count for {1}:\n".format(contest_number, states_array[state]))
    print("\t CANDIDATE \t\t COUNT \t\t\t\t PERCENTAGE")
    print("-----------------------------------------------------------")
    print("\t Biden: \t\t{0:,} Votes\t\t{1:.2%}".format(biden_votes_array[state], biden_popular_percentage))
    print("\t Trump: \t\t{0:,} Votes\t\t{1:.2%}".format(trump_votes_array[state], trump_popular_percentage))
    print("\t Independent: \t{0:,} Votes\t\t{1:.2%}".format(independent_votes_array[state], independent_popular_percentage))
    print("\t Total: \t\t{0:,} Votes".format(total_votes_array[state]))
    if biden_votes_array[state] > trump_votes_array[state]:
        biden_electoral_votes += electoral_votes_array[state]
        print("\nBiden wins {0} Electoral Votes from {1}!".format(electoral_votes_array[state], states_array[state]))
    else:
        trump_electoral_votes += electoral_votes_array[state]
        print("\nTrump wins {0} Electoral Votes from {1}!".format(electoral_votes_array[state], states_array[state]))

    biden_electoral_percentage = biden_electoral_votes / cumulative_electoral_votes
    trump_electoral_percentage = trump_electoral_votes / cumulative_electoral_votes
    independent_electoral_percentage = independent_electoral_votes / cumulative_electoral_votes

    print("\nElectoral & Popular Vote Count Update:")
    print("\t CANDIDATE \t\t\t POPULAR VOTES \t\t\t PERCENTAGE \t ELECTORAL VOTES \t PERCENTAGE")
    print("\t Biden: \t\t\t {0:,} Votes \t\t {1:.2%} \t\t {2} \t\t\t\t {3:.2%}".format(biden_popular_votes, biden_popular_percentage, biden_electoral_votes, biden_electoral_percentage))
    print("\t Trump: \t\t\t {0:,} Votes \t\t {1:.2%} \t\t {2} \t\t\t\t {3:.2%}".format(trump_popular_votes, trump_popular_percentage, trump_electoral_votes, trump_electoral_percentage))
    print("\t Independent: \t\t {0:,} Votes \t\t {1:.2%} \t\t\t {2} \t\t\t\t\t {3:.2%}".format(independent_popular_votes, independent_popular_percentage, independent_electoral_votes, independent_electoral_percentage))

    contests_remaining = total_contests - contest_number
    print("\n Election contests remaining: {0}\n".format(contests_remaining))
    contest_number += 1

print("**************************************************************************")
print("*********************E*L*E*C*T*I*O*N***R*E*S*U*L*T*S**********************")
print("**************************************************************************\n")

if biden_electoral_votes > trump_electoral_votes:
    winner = "Joe Biden"
    winning_electoral_votes = biden_electoral_votes
elif trump_electoral_votes > biden_electoral_votes:
    winner = "Donald Trump"
    winning_electoral_votes = trump_electoral_votes
else:
    winner = "yet to be determined by Congress!"
    winning_electoral_votes = total_electoral_votes / 2

# The election results are produced as such:
def election_results(biden_electoral_votes, trump_electoral_votes):
    print("The winner with {0} electoral votes is {1}!".format(winning_electoral_votes, winner))
    print("\n\nFinal Popular Vote Count:")
    print("\t Biden: {0:,}".format(biden_popular_votes))
    print("\t Trump: {0:,}".format(trump_popular_votes))
    print("\t Independent: {0:,}".format(independent_popular_votes))
    print("\nFinal Electoral Vote Count:")
    print("\t Biden: {0}".format(biden_electoral_votes))
    print("\t Trump: {0}".format(trump_electoral_votes))
    print("\t Independent: {0}".format(independent_electoral_votes))

election_results(biden_electoral_votes, trump_electoral_votes)