biden_votes_array = []

# Biden Vote Counts:
biden_votes_AL = 834_533
biden_votes_AK = 64_246
biden_votes_AZ = 1_645_359
biden_votes_AR = 417_897
biden_votes_CA = 9_343_525
biden_votes_CO = 1_753_416
biden_votes_CT = 1_070_380
biden_votes_DC = 258_625
biden_votes_DE = 295_403
biden_votes_FL = 5_284_453
biden_votes_GA = 2_467_870
biden_votes_HI = 365_802
biden_votes_ID = 286_991
biden_votes_IL = 3_056_219
biden_votes_IN = 1_239_401
biden_votes_IA = 757_905
biden_votes_KS = 551_144
biden_votes_KY = 772_285
biden_votes_LA = 855_597
biden_votes_ME = 420_023
biden_votes_MD = 1_625_505
biden_votes_MA = 2_316_338
biden_votes_MI = 2_790_648
biden_votes_MN = 1_717_935
biden_votes_MS = 440_284
biden_votes_MO = 1_242_851
biden_votes_MT = 243_719
biden_votes_NE = 367_919
biden_votes_NV = 670_344
biden_votes_NH = 423_291
biden_votes_NJ = 2_206_781
biden_votes_NM = 496_826
biden_votes_NY = 3_702_263
biden_votes_NC = 2_659_528
biden_votes_ND = 114_684
biden_votes_OH = 2_603_731
biden_votes_OK = 503_829
biden_votes_OR = 1_304_536
biden_votes_PA = 3_365_798
biden_votes_RI = 300_325
biden_votes_SC = 1_091_348
biden_votes_SD = 150_467
biden_votes_TN = 1_139_666
biden_votes_TX = 5_218_631
biden_votes_UT = 505_250
biden_votes_VT = 242_805
biden_votes_VA = 2_379_830
biden_votes_WA = 2_316_582
biden_votes_WV = 232_502
biden_votes_WI = 1_630_570
biden_votes_WY = 73_445

# Add each individual state into the array:
biden_votes_array.insert(0, biden_votes_AL)
biden_votes_array.insert(1, biden_votes_AK)
biden_votes_array.insert(2, biden_votes_AZ)
biden_votes_array.insert(3, biden_votes_AR)
biden_votes_array.insert(4, biden_votes_CA)
biden_votes_array.insert(5, biden_votes_CO)
biden_votes_array.insert(6, biden_votes_CT)
biden_votes_array.insert(7, biden_votes_DC)
biden_votes_array.insert(8, biden_votes_DE)
biden_votes_array.insert(9, biden_votes_FL)
biden_votes_array.insert(10, biden_votes_GA)
biden_votes_array.insert(11, biden_votes_HI)
biden_votes_array.insert(12, biden_votes_ID)
biden_votes_array.insert(13, biden_votes_IL)
biden_votes_array.insert(14, biden_votes_IN)
biden_votes_array.insert(15, biden_votes_IA)
biden_votes_array.insert(16, biden_votes_KS)
biden_votes_array.insert(17, biden_votes_KY)
biden_votes_array.insert(18, biden_votes_LA)
biden_votes_array.insert(19, biden_votes_ME)
biden_votes_array.insert(20, biden_votes_MD)
biden_votes_array.insert(21, biden_votes_MA)
biden_votes_array.insert(22, biden_votes_MI)
biden_votes_array.insert(23, biden_votes_MN)
biden_votes_array.insert(24, biden_votes_MS)
biden_votes_array.insert(25, biden_votes_MO)
biden_votes_array.insert(26, biden_votes_MT)
biden_votes_array.insert(27, biden_votes_NE)
biden_votes_array.insert(28, biden_votes_NV)
biden_votes_array.insert(29, biden_votes_NH)
biden_votes_array.insert(30, biden_votes_NJ)
biden_votes_array.insert(31, biden_votes_NM)
biden_votes_array.insert(32, biden_votes_NY)
biden_votes_array.insert(33, biden_votes_NC)
biden_votes_array.insert(34, biden_votes_ND)
biden_votes_array.insert(35, biden_votes_OH)
biden_votes_array.insert(36, biden_votes_OK)
biden_votes_array.insert(37, biden_votes_OR)
biden_votes_array.insert(38, biden_votes_PA)
biden_votes_array.insert(39, biden_votes_RI)
biden_votes_array.insert(40, biden_votes_SC)
biden_votes_array.insert(41, biden_votes_SD)
biden_votes_array.insert(42, biden_votes_TN)
biden_votes_array.insert(43, biden_votes_TX)
biden_votes_array.insert(44, biden_votes_UT)
biden_votes_array.insert(45, biden_votes_VT)
biden_votes_array.insert(46, biden_votes_VA)
biden_votes_array.insert(47, biden_votes_WA)
biden_votes_array.insert(48, biden_votes_WV)
biden_votes_array.insert(49, biden_votes_WI)
biden_votes_array.insert(50, biden_votes_WY)